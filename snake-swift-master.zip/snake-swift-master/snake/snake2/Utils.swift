//
//  Utils.swift
//  snake
//
//  Created by  Igor Nadiein on 11.05.2020.
//  Copyright © 2020  Igor Nadiein. All rights reserved.
//

import Foundation

class Utils {
    static func generateRandomNumber(max:Int) -> Int { return Int.random(in: 0...max) }
}
