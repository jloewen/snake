//
//  BoardModel.swift
//  snake
//
//  Created by  Igor Nadiein on 11.05.2020.
//  Copyright © 2020  Igor Nadiein. All rights reserved.
//

import Foundation

class BoardModel {
    public var width:Int16?
    public var height:Int16?
    public var x:Int16?
    public var y:Int16?
}
